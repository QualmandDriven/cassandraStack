Dateien für Hausarbeit Apache Cassandra.

Datenbank:
Konfiguration von einem Cassandra-Knoten wird in cassandra.yaml dargestellt.

Anwendung:
Die Anwendung verwendet zur Vereinfachung Docker-Compose, welches eine Cassandra-Datenbank und die Web-Anwendung startet.
"server.py" enthählt die Anwendung und kann unter localhost:5000 nach "docker-compose up" aufgerufen werden.
Oder via Editor betrachtet werden.

